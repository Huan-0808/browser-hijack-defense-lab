# Lab Labtainer: browser-hijack-defense

## Kịch bản
Máy trạm "workstation" của một nhân viên NovaCorp bị nghi dính browser hijacker: khi mở Firefox, trang chủ tự động chuyển sang một trang quảng cáo lạ (http://ads.local:8080/) và công cụ tìm kiếm mặc định bị đổi khác thường (AdsSearch). Bộ phận CNTT đã cô lập 3 extension nghi vấn tìm thấy trên máy, đặt sẵn vào thư mục ~/incident/extensions/ext-a/, ext-b/, ext-c/, mỗi extension CHỈ gồm file manifest.json (khai báo tĩnh, không có mã JavaScript thực thi gì nguy hại) để sinh viên phân tích. Sinh viên đóng vai kỹ sư bảo mật, nhiệm vụ: xác nhận triệu chứng, phân tích quyền của 3 extension, xác định đúng extension là thủ phạm (dựa vào trường chrome_settings_overrides trỏ tới ads.local:8080), gỡ bỏ và khôi phục cấu hình, sau đó triển khai chính sách doanh nghiệp thông qua cơ chế AutoConfig chuẩn của Mozilla (mozilla.cfg và local-settings.js) để khóa trang chủ (http://novacorp.local:8080/), khóa công cụ tìm kiếm (NovaSearch) và chặn hoàn toàn việc cài đặt extension mới (xpinstall.enabled = false), cuối cùng kiểm chứng chính sách có hiệu lực.

## Cấu hình
1 container "workstation" (base image labtainer.firefox), có sẵn:
- Một Firefox profile đã bị "nhiễm": file user.js trong profile ghi đè user_pref("browser.startup.homepage", "http://ads.local:8080/") và user_pref("browser.search.defaultenginename", "AdsSearch").
- Thư mục ~/incident/extensions/ chứa 3 extension (chỉ manifest.json, không có background script thực thi):
  - ext-a: quyền tối thiểu (storage), không có chrome_settings_overrides — vô hại, dùng để đánh lạc hướng.
  - ext-b: có chrome_settings_overrides.homepage trỏ http://ads.local:8080/ và search_provider trỏ AdsSearch, kèm host_permissions "<all_urls>" và permissions "webRequest", "tabs", "history" — đây là thủ phạm.
  - ext-c: permissions rộng (tabs, history) nhưng không có chrome_settings_overrides — đáng ngờ nhưng không phải thủ phạm, dùng để rèn kỹ năng đọc kỹ chứ không đoán bừa.
- Web server nội bộ (mock_server.py) chạy trên cổng 8080 phục vụ trang quảng cáo http://ads.local:8080/ và trang nội bộ http://novacorp.local:8080/, tự khởi động một lần duy nhất qua workstation/_bin/fixlocal.sh.

## 6 task cho sinh viên
Task 1: xác nhận triệu chứng — xem nội dung user.js hiện tại của profile (cat), ghi lại trang chủ và search engine bị đổi vào file ~/incident/trieu_chung.txt.
Task 2: liệt kê và trích quyền của cả 3 extension — dùng lệnh (cat/grep/python) in ra trường "permissions", "host_permissions" và "chrome_settings_overrides" của từng manifest.json, lưu kết quả vào ~/incident/quyen_extension.txt.
Task 3: phân tích và kết luận — dựa vào Task 2, xác định đúng extension thủ phạm, ghi lý do vào ~/incident/ketluan.txt (phải nêu rõ tên field chrome_settings_overrides và giá trị ads.local:8080).
Task 4: gỡ bỏ và khôi phục — xoá thư mục extension thủ phạm khỏi hệ thống, sửa lại user.js xoá hai dòng user_pref bị hijack, ghi log hành động vào ~/incident/go_bo.log.
Task 5: triển khai chính sách doanh nghiệp — cấu hình cơ chế AutoConfig chuẩn của Mozilla:
  - Tạo file /usr/lib/firefox/defaults/pref/local-settings.js nạp file mozilla.cfg:
    pref("general.config.obscure_value", 0);
    pref("general.config.filename", "mozilla.cfg");
  - Tạo file /usr/lib/firefox/mozilla.cfg (dòng đầu tiên là comment //) khóa Homepage về http://novacorp.local:8080/, khóa default search engine về NovaSearch, và chặn hoàn toàn việc cài đặt extension mới bằng lockPref("xpinstall.enabled", false).
Task 6: kiểm chứng — khởi động lại Firefox, kiểm tra about:config xác nhận các khóa browser.startup.homepage và xpinstall.enabled ở trạng thái locked (in đậm); chạy script kiểm tra tự động ./check_policy.py in ra "PASS" khi toàn bộ cấu hình đáp ứng yêu cầu.

## results.config và goals.config
results.config:
r_trieuchung = workstation:incident/trieu_chung.txt : CONTAINS : ads.local:8080
r_quyen = workstation:incident/quyen_extension.txt : CONTAINS : chrome_settings_overrides
r_ketluan = workstation:incident/ketluan.txt : CONTAINS : ext-b
r_gobo = workstation:incident/go_bo.log : CONTAINS : ext-b
r_policy = workstation:/usr/lib/firefox/mozilla.cfg : CONTAINS : lockPref("browser.startup.homepage", "http://novacorp.local:8080/")
r_verify = workstation:check_policy.py.stdout : CONTAINS : PASS

goals.config:
g_trieuchung = boolean : r_trieuchung
g_quyen = boolean : r_quyen
g_ketluan = boolean : r_ketluan
g_gobo = boolean : r_gobo
g_policy = boolean : r_policy
g_verify = boolean : r_verify

LƯU Ý QUAN TRỌNG:
- r_verify dựa trên kết quả chạy thật của check_policy.py thông qua cơ chế treataslocal và capinout của Labtainers (ghi log vào ~/.local/result/check_policy.py.stdout.<timestamp>). Sinh viên tự gõ PASS vào file sẽ không được tính điểm.
- Người dùng có thể dùng sudo để sửa các file trong /usr/lib/firefox/. Mật khẩu tài khoản ubuntu là ubuntu.

## Quy ước chung
Cấu trúc Labtainer chuẩn: config/start.config (1 container, USER ubuntu, PASSWORD ubuntu, X11 YES), instr_config/results.config, instr_config/goals.config (tên goal khác tên result), dockerfiles/, docs/. Không bao giờ viết mã JavaScript hay script nào thực sự thực hiện hành vi hijacking (đổi trang, chuyển hướng, theo dõi) — toàn bộ 3 extension mẫu chỉ có manifest.json khai báo, tuyệt đối không có background.js hay content script nào chạy thật. Không bao giờ in hoặc ghi mật khẩu, token vào file. Báo cáo viết tiếng Việt theo 7 mục: giới thiệu, nội dung và hướng dẫn, phân tích yêu cầu, thiết kế (có bảng Result), cài đặt và cấu hình, tích hợp và triển khai (Docker Hub, GitHub), thử nghiệm và đánh giá.
